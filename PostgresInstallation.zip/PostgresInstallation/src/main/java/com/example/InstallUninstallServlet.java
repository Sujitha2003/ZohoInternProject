package com.example;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/InstallUninstallServlet")
public class InstallUninstallServlet extends HttpServlet {
    private static final int PORT_RANGE_START = 5436;
    private static final int PORT_RANGE_END = 5500;
    public static int port;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
        String action = request.getParameter("action");
        if ("install".equals(action)) {
            installPostgreSQL(request, response);
        } else if ("uninstall".equals(action)) {
            uninstallPostgreSQL(request, response);
        } 
    }

    private void installPostgreSQL(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String version = request.getParameter("version");
        String location = request.getParameter("installationDir");

        port = findAvailablePort();
        if (port == -1) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,"No available port found");
            return;
        }

       
        
        String baseDir = "/home/sujitha-si2710/"+location;
        String installCommand = "/bin/bash -c \"cd " + baseDir + " && " +
                "wget http://localhost/postgresql-" + version + "-bin.tar.gz && " +
                "tar xzf postgresql-" + version + "-bin.tar.gz && " +
                "mkdir -p " + baseDir + "/postgresql-" + version + "/data && " +
                baseDir + "/postgresql-" + version + "/bin/initdb -D " + baseDir + "/postgresql-" + version + "/data && " +
                "echo 'port = " + port + "' >> " + baseDir + "/postgresql-" + version + "/data/postgresql.conf\"";
              

        ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", installCommand);
        processBuilder.inheritIO();
        Process process = processBuilder.start();


        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.getMessage();
        }

        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            String sql = "INSERT INTO installed_versions (version, location, port, status) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, version);
            statement.setString(2, location);
            statement.setInt(3, port);
            statement.setString(4, "stop");
            statement.executeUpdate();

            String activity = "Installed v" + version + " in " + location;
            sql = "INSERT INTO activity (activity) VALUES (?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1, activity);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>PostgreSQL Installation Completed</h1>");
        out.println("</body></html>");
    }

    private void uninstallPostgreSQL(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String version = request.getParameter("version");
        String location = request.getParameter("installationDir");


        String uninstallCommand = "/bin/bash -c \"" +
                                   "rm -rf /home/sujitha-si2710/" + location + "/postgresql-13.1/data && " +
                                   "rm -rf /home/sujitha-si2710/" + location + "/postgresql-13.1/bin && " +
                                   "rm -rf /home/sujitha-si2710/" + location + "/postgresql-13.1/include && " +
                                   "rm -rf /home/sujitha-si2710/" + location + "/postgresql-13.1/lib && " +
                                   "rm -rf /home/sujitha-si2710/" + location + "/postgresql-13.1/share && " +
                                   "rm -rf /home/sujitha-si2710/"+location+"/postgresql-13.1/postgresql-" + version + " && " +
                                   "rm -rf /home/sujitha-si2710/"+location+"/postgresql-13.1/postgresql-" + version + ".tar.gz && " +
                                   "rm -rf /home/sujitha-si2710/"+location+"/postgresql-13.1  && " +
                                   "rm -rf /etc/postgresql/ && " +
                                   "rm -rf /var/lib/postgresql/ && " +
                                   "rm -rf /var/log/postgresql/ && " +
                                   "apt-get autoremove && " +
                                   "apt-get autoclean\"";

        try {
            ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", uninstallCommand);
            processBuilder.inheritIO();
            Process process = processBuilder.start();
            process.waitFor();
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }

        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            String sql = "DELETE FROM installed_versions WHERE version = ? AND location = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, version);
            statement.setString(2, location);
            statement.executeUpdate();

            String activity = "Uninstalled v" + version + " from " + location;
            sql = "INSERT INTO activity (activity) VALUES (?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1, activity);
            statement.executeUpdate();
            
           
        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>PostgreSQL Uninstallation Completed</h1>");
        out.println("</body></html>");
    }

    private int findAvailablePort() {
        for (int port = PORT_RANGE_START; port <= PORT_RANGE_END; port++) {
            if (isPortInUse(port)) {
                return port;
            }
        }
        return -1;
    }

    private boolean isPortInUse(int port) {
        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            String sql1 = "SELECT COUNT(*) FROM installed_versions WHERE port = ?";
            String sql2 = "SELECT count(*) FROM replication WHERE replicaport LIKE ?";
            PreparedStatement statement = connection.prepareStatement(sql1);
            statement.setInt(1, port);
            ResultSet resultSet = statement.executeQuery();
            int count1=0;
            if (resultSet.next()) {
                count1 = resultSet.getInt(1);
            }
            statement = connection.prepareStatement(sql2);
            statement.setString(1, "%" + port + "%");
            resultSet = statement.executeQuery();
            int count2=0;
            if (resultSet.next()) {
                count2 = resultSet.getInt(1);
            }
           
            return count1 ==0 &&  count2==0;
             
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}

