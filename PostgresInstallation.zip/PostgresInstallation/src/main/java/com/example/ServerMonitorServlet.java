package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.io.File;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;

@WebServlet("/server-monitor")
public class ServerMonitorServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "postgres";

    private ScheduledExecutorService executor;
    int count = 0; 
    @Override
    public void init() throws ServletException {
        super.init();
        
        executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(new ServerStatusChecker(), 0, 10, TimeUnit.SECONDS);
    }

    private class ServerStatusChecker implements Runnable {
        @Override
        public void run() {
            boolean mstatus;
            boolean sstatus=false;
            try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String sql = "SELECT master, masterport, replicaport FROM replication";
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    String repport = "";
                    String master = resultSet.getString("master");
                    String rports = resultSet.getString("replicaport");
                    int mport = resultSet.getInt("masterport");
                    String[] replicaPorts = rports.split(" ");
                    mstatus = checkServerStatus(mport);
                    updateStatusInDatabase(mport, mstatus);

                    if (!mstatus) {
                    	mstatus=checkFromServer(mport);
                    	if(!mstatus) {
                        count++;
                        int qres = QuorumPrimarySelection(replicaPorts, master);
                        int newmaster;
                        if (qres == -1) {
                            newmaster = selectActiveStandby(replicaPorts,master,InstallUninstallServlet.port + 1);
                        } else {
                            newmaster = Integer.parseInt(replicaPorts[qres]);
                        }
                        mport = newmaster;
                        int r = ++InstallUninstallServlet.port;
                        String dataFolder = getUniqueDataFolderName(master, qres+1);
                        configurepreserver(master, dataFolder, mport, r);
                        repport += r + " ";
                        String sql1 = "UPDATE replication SET masterport = ? WHERE master = ?";
                        try (PreparedStatement statement1 = connection.prepareStatement(sql1)) {
                            statement1.setInt(1, newmaster);
                            statement1.setString(2, master);
                            statement1.executeUpdate();
                        }
                        catch (Exception e) {
                            System.err.println(e.getMessage());
                        }
                        
                    }
                    }
                    if(mstatus) {
                    	try (Connection connection2 = DriverManager.getConnection("jdbc:postgresql://localhost:"+mport+"/postgres", "replicator", "replicator")) {
                        	String q2 = "SELECT COUNT(*) from pg_stat_replication where state='streaming'";
                            PreparedStatement st2 = connection.prepareStatement(q2);
                            ResultSet res2 = st2.executeQuery();
                            if(res2.next())
                            if(res2.getInt(1)==ReplicationServlet.count)
                            	sstatus=true;
                            
                    	}
                    	catch (SQLException e) {
                            System.err.println(e.getMessage());
                        }
                    }
     
                    
                    
                    if(!sstatus) {
                    for (int i=0;i<replicaPorts.length;i++) {
                        sstatus = checkServerStatus(Integer.parseInt(replicaPorts[i]));
                        if (sstatus) {
                            repport += replicaPorts[i] + " ";
                        } else {
                        	sstatus=checkFromServer(Integer.parseInt(replicaPorts[i]));
                        	if(!sstatus) {
                        
                            count++;
                            String dataFolder = getUniqueDataFolderName(master, count);
                            int rport = ++InstallUninstallServlet.port;
                            configurepreserver(master, dataFolder, mport, rport);
                            repport += rport + " ";
                            try (PreparedStatement stat = connection.prepareStatement("DELETE FROM server_status WHERE port = ?")) {
                                stat.setInt(1, Integer.parseInt(replicaPorts[i]));
                                stat.executeUpdate();
                            }
                        }
                        }
                    }
                    }
                    if (count != 0 && mstatus != false) {
                        try (PreparedStatement stat = connection.prepareStatement("UPDATE replication SET replicaport = ? WHERE master = ?")) {
                            stat.setString(1, repport.trim());
                            stat.setString(2, master);
                            stat.executeUpdate();
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    private boolean checkServerStatus(int port) throws SQLException {
        String dbUrl = "jdbc:postgresql://localhost:" + port + "/postgres";
        String username = "replicator";
        String password = "replicator";
        try (Connection connection = DriverManager.getConnection(dbUrl, username, password)) {
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void updateStatusInDatabase(int port, boolean isServerRunning) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String updateQuery = "UPDATE server_status SET status = ? WHERE port = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
                pstmt.setString(1, isServerRunning ? "Active" : "Inactive");
                pstmt.setInt(2, port);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    private int QuorumPrimarySelection(String[] p, String cluster) {
        int q = (p.length / 2)+1;
        int index = 0;
        boolean allNull = true;

        for (int i = 0; i < p.length; i++) {
            int count = 1;
            try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:" + p[i] + "/postgres", "replicator", "replicator")) {
                String sql = "SELECT EXTRACT(EPOCH FROM now() - pg_last_xact_replay_timestamp())";
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                if(resultSet.next() && resultSet.getObject(1) == null)
                	continue;
                if (resultSet.next() && resultSet.getObject(1) != null) {
                    allNull = false;
                    long t1 = (long) (resultSet.getDouble(1) * 1000);
                    for (int j = 0; j < p.length; j++) {
                        if (i != j) {
                            try (Connection connection2 = DriverManager.getConnection("jdbc:postgresql://localhost:" + p[j] + "/postgres", "replicator", "replicator")) {
                                String sql2 = "SELECT EXTRACT(EPOCH FROM now() - pg_last_xact_replay_timestamp())";
                                PreparedStatement statement2 = connection2.prepareStatement(sql2);
                                ResultSet resultSet2 = statement2.executeQuery();
                                if (resultSet2.next() && resultSet2.getObject(1) != null) {
                                    long t2 = (long) (resultSet2.getDouble(1) * 1000);
                                    if (t1 <= t2) {
                                        count++;
                                    }
                                }
                            } catch (Exception e) {
                                System.err.println(e.getMessage());
                            }
                        }
                    }
                    if (count >= q) {
                        index = i;
                        promoteStandby(p, i, cluster, InstallUninstallServlet.port + 1);
                        break;
                    }
                }
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }

        return allNull ? -1 : index;
    }

    private void promoteStandby(String[] servers, int index, String location,int newport) throws IOException, InterruptedException {
        String command = "~/"+location+"/postgresql-13.1/bin/pg_ctl promote -D ~/"+location+"/postgresql-13.1/data" + (servers.length-index);
        ProcessBuilder finalProcessBuilder = new ProcessBuilder("/bin/bash", "-c", command);
        Process finalProcess = finalProcessBuilder.start();
        finalProcess.waitFor();
        String r=newport+" ";
        for (int j = 0; j < servers.length; j++) {
        	if(j!=index) 
        	r+=(servers[j]+" ");
            if ((servers.length-j)!=j) {
                String newConninfo = "primary_conninfo = 'host=127.0.0.1 port=" + servers[index] + " user=replicator password=replicator'";
                String sedCommand = "sed -i \"s/^primary_conninfo.*/" + newConninfo.replaceAll("\\$", "\\\\$") + "/\" ~/" + location + "/postgresql-13.1/data" + (j + 1) + "/postgresql.auto.conf";
                command = sedCommand + " && ";
                command += "~/"+location+"/postgresql-13.1/bin/pg_ctl -D ~/"+location+"/postgresql-13.1/data" + (j + 1) + " restart";
                finalProcessBuilder = new ProcessBuilder("/bin/bash", "-c", command);
                finalProcess = finalProcessBuilder.start();
                finalProcess.waitFor();
            }
        }
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)){
        try (PreparedStatement stat = conn.prepareStatement("UPDATE replication SET replicaport = ? WHERE master = ?")) {
        	
            stat.setString(1, r.trim());
            stat.setString(2, location);
            stat.executeUpdate();
        }
        }
        catch (Exception e) {
            System.err.println(e.getMessage());
        }
        

    }  
    private String getUniqueDataFolderName(String master, int count) {
        int i = count;
        String dataFolder;
        do {
            dataFolder = "preserver" + i++;
        } while (new File("~/"+master+"/postgresql-13.1/" + dataFolder).exists());
        return dataFolder;
    }

    private void configurepreserver(String master, String dataFolder, int mport, int rport) throws IOException {
        String baseBackupCommand = "~/" + master + "/postgresql-13.1/bin/pg_basebackup -h 127.0.0.1 -p " + mport
                + " -D " + "~/" + master + "/postgresql-13.1/" + dataFolder
                + " -U replicator -P -v --wal-method=stream -R";
      
        String addPortCommand = "sed -i \"s/^port .*/port " + rport + "/\" " + "~/" + master + "/postgresql-13.1/" + dataFolder + "/postgresql.conf";
        String startReplicaCommand = "~/" + master + "/postgresql-13.1" + "/bin/pg_ctl -D " + "~/" + master + "/postgresql-13.1" + "/" + dataFolder + " start";
        String[] commands = {baseBackupCommand, addPortCommand, startReplicaCommand};

        for (String command : commands) {
            executeCommand(command);
        }
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
        try (PreparedStatement stat = conn.prepareStatement("INSERT INTO server_status (port, status) VALUES (?, ?)")) {
            stat.setInt(1, rport);
            stat.setString(2, "Active");
            stat.executeUpdate();
        }
        
    } catch (SQLException e) {
        System.err.println(e.getMessage());
    }
        System.out.println("preserver completed");
        }

    private void executeCommand(String command) throws IOException {
        ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", command);
        processBuilder.inheritIO();
        Process process = processBuilder.start();

        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private int selectActiveStandby(String[] p,String location,int newport) throws IOException, InterruptedException {
        for (int i = 0; i < p.length; i++) {
            try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String sql = "SELECT status FROM server_status WHERE port = ?";
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setInt(1, Integer.parseInt(p[i]));
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next() && "Active".equals(resultSet.getString("status"))) {
                	promoteStandby(p,i,location,newport);
                    return Integer.parseInt(p[i]);
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
        return -1;
    }
    private boolean checkFromServer(int port) {
        Connection c = null;
        Statement stmt = null;
        boolean result = false;

        try {
            c = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            stmt = c.createStatement();

            String createServerSQL = String.format(
                "CREATE SERVER remote_server FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host '127.0.0.1', dbname 'postgres', port '%d');",
                port
            );
            String createUserMappingSQL = 
                "CREATE USER MAPPING FOR postgres SERVER remote_server OPTIONS (user 'replicator', password 'replicator');";
            String importSchemaSQL = 
                "IMPORT FOREIGN SCHEMA public FROM SERVER remote_server INTO public;";
            String selectSQL = 
                "SELECT 1;";

            stmt.executeUpdate(createServerSQL);
            stmt.executeUpdate(createUserMappingSQL);
            stmt.executeUpdate(importSchemaSQL);

            ResultSet rs = stmt.executeQuery(selectSQL);
            if (rs.next()) {
                result = true;
            }

            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.executeUpdate("DROP SERVER IF EXISTS remote_server CASCADE;");
                    stmt.close();
                }
                if (c != null) {
                    c.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return result;
    }
}