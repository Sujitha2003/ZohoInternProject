package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ReplicationServlet")
public class ReplicationServlet extends HttpServlet {
	static int count;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String primaryLocation = request.getParameter("cluster");
        int primaryPort = 0;
        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            String sql = "SELECT port FROM installed_versions WHERE location = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, primaryLocation);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        primaryPort = resultSet.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String type = request.getParameter("replicatype");
        count = Integer.parseInt(request.getParameter("count"));
        try {
            ConfigurePrimaryServer(primaryLocation, primaryPort, count,type);
            ConfigureReplicaServer(primaryLocation, primaryPort, count,type);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>PostgreSQL Replication Setup Completed</h1>");
        out.println("</body></html>");
   
    }

    private void ConfigurePrimaryServer(String location, int port, int count,String type) throws IOException {
        String primaryServerLocation = "/home/sujitha-si2710/" + location + "/postgresql-13.1";
        
        if(type.equals("Asynchronous")) {

        String updateConfigCommand = "echo \"wal_level = replica\n" +
                    "wal_log_hints = on\n" +
                    "max_wal_senders = 8\n" +
                    "max_wal_size = 1GB\n" +
                    "hot_standby = on\" >> " + primaryServerLocation + "/data/postgresql.conf";
        
        

        String startServerCommand = primaryServerLocation + "/bin/pg_ctl -D " + primaryServerLocation + "/data start";
        String stopServerCommand = primaryServerLocation + "/bin/pg_ctl -D " + primaryServerLocation + "/data stop";
        String singleUserModeCommand = primaryServerLocation + "/bin/postgres --single -p " + port + " -D " + primaryServerLocation + "/data template1";
        String createSuperUserCommand = "echo \"CREATE USER postgres WITH SUPERUSER;\" | " + singleUserModeCommand;
        String restartServerCommand = primaryServerLocation + "/bin/pg_ctl -D " + primaryServerLocation + "/data start";
        String createReplicatorUserCommand = primaryServerLocation + "/bin/psql -U postgres -p " + port + " -c \"CREATE USER replicator WITH REPLICATION ENCRYPTED PASSWORD 'replicator';\"";
        String finalRestartCommand = primaryServerLocation + "/bin/pg_ctl -D " + primaryServerLocation + "/data restart";
        String[] commands = {updateConfigCommand,startServerCommand, stopServerCommand, createSuperUserCommand, restartServerCommand, createReplicatorUserCommand, finalRestartCommand};

        for (String command : commands) {
            executeCommand(command);
        }

        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            String sql = "INSERT INTO server_status (port, status,datafolder) VALUES (?, ?,?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, port);
                statement.setString(2, "Active");
                statement.setString(3, "data");
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.print("Primary completed");
    }
        else {
        	String replica="";
        	while(count>0) {
        		replica+="standby"+count;
        		if(count-1!=0) {
        			replica+=",";
        		}
        		count--;
        	}
        	String singleUserModeCommand = primaryServerLocation + "/bin/postgres --single -p " + port + " -D " + primaryServerLocation + "/data template1";
            String createSuperUserCommand = "echo \"CREATE USER postgres WITH SUPERUSER;\" | " + singleUserModeCommand;
            String startServerCommand = primaryServerLocation + "/bin/pg_ctl -D " + primaryServerLocation + "/data start";
            String createReplicatorUserCommand = primaryServerLocation + "/bin/psql -U postgres -p " + port + " -c \"CREATE USER replicator WITH REPLICATION ENCRYPTED PASSWORD 'replicator';\"";
            
            String updateConfigCommand = "echo \"listen_addresses = '*'\n" +
                    "wal_level = replica\n" +
                    "max_wal_senders = 10\n" +
                    "synchronous_commit = on\n" +
                    "synchronous_standby_names = '" + replica + "'\" >> " + primaryServerLocation + "/data/postgresql.conf";

            String restartServerCommand = primaryServerLocation + "/bin/pg_ctl -D " + primaryServerLocation + "/data -o \"-p " + port + "\" restart";
            
            String[] commands = {createSuperUserCommand, startServerCommand, createReplicatorUserCommand, updateConfigCommand, restartServerCommand};

            for (String command : commands) {
                executeCommand(command);
            }

            try (Connection connection = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
                String sql = "INSERT INTO server_status (port, status,datafolder) VALUES (?, ?,?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, port);
                    statement.setString(2, "Active");
                    statement.setString(3, "data");
                    statement.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            System.out.print("Primary completed");
        }
    
    }

    private void ConfigureReplicaServer(String primaryLocation, int primaryPort, int count,String type) throws IOException {
        String replicaServerLocation = "/home/sujitha-si2710/" + primaryLocation + "/postgresql-13.1";
        int primaryServerPort = primaryPort;
        int temp = count;
        String repport = "";
        while (count > 0) {
            String dataFolder = "data" + count;
            int rport = ++InstallUninstallServlet.port;
            if(type.equals("Asynchronous")) {
            String baseBackupCommand = replicaServerLocation + "/bin/pg_basebackup -h 127.0.0.1 -p " + primaryServerPort
                    + " -D " + replicaServerLocation + "/" + dataFolder
                    + " -U replicator -P -v --wal-method=stream -R";
            
            String addPortCommand = "sed -i \"s/^port .*/port " + rport + "/\" " + primaryLocation + "/postgresql-13.1/data" + count + "/postgresql.conf";
            String startReplicaCommand = replicaServerLocation + "/bin/pg_ctl -D " + replicaServerLocation + "/" + dataFolder + " start";
            String[] commands = {baseBackupCommand,  addPortCommand, startReplicaCommand};

            for (String command : commands) {
                executeCommand(command);
            }
            }
            else  {
            	String baseBackupCommand = replicaServerLocation + "/bin/pg_basebackup -h 127.0.0.1 -p " + primaryServerPort
                        + " -D " + replicaServerLocation + "/" + dataFolder
                        + " -U replicator -P -v --wal-method=stream -R";
                String removeReplicaConfigCommand="sed -i '/^primary_conninfo/d' ~/" + primaryLocation + "/postgresql-13.1/" + dataFolder+ "/postgresql.auto.conf";
                String updateReplicaConfigCommand = "echo \"primary_conninfo = 'host=127.0.0.1 port=" + primaryServerPort
                        + " user=replicator password=replicator application_name=standby" + count + "'\" >> " 
                        + replicaServerLocation + "/" + dataFolder + "/postgresql.auto.conf";
                String addPortCommand = "sed -i \"s/^port .*/port " + rport + "/\" " + primaryLocation + "/postgresql-13.1/data" + count + "/postgresql.conf";
                String startReplicaCommand = replicaServerLocation + "/bin/pg_ctl -D " + replicaServerLocation + "/" + dataFolder + " start";
                String[] commands = {baseBackupCommand, removeReplicaConfigCommand, updateReplicaConfigCommand, addPortCommand, startReplicaCommand};

                for (String command : commands) {
                    executeCommand(command);
                }	
            }
            try (Connection connection = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            	 String sql = "INSERT INTO server_status (port,datafolder,status) VALUES (?,?,?)";
                 PreparedStatement statement = connection.prepareStatement(sql);
                 statement.setInt(1, rport);
                 statement.setString(2, dataFolder);
                 statement.setString(3, "Active");
                 statement.executeUpdate();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            repport += rport+" ";
            	
            count--;
            }
        

        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            String sql = "INSERT INTO replication (master, masterport, replicacount, replicaport,type) VALUES (?, ?, ?, ?,?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, primaryLocation);
                statement.setInt(2, primaryPort);
                statement.setInt(3, temp);
                statement.setString(4, repport);
                statement.setString(5, type);
                statement.executeUpdate();
            }

            sql = "INSERT INTO activity (activity) VALUES (?)";
            String activity = "Replication on Primary:" + primaryPort + " & Replica: count=" + temp;
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, activity);
                statement.executeUpdate();
            }

            sql = "UPDATE installed_versions SET status = ? WHERE port = ?";
            activity = "Server started at port:" + primaryPort;
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, "start");
                statement.setInt(2, primaryPort);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private  void executeCommand(String command) throws IOException {
        ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", command);
        processBuilder.inheritIO();
        Process process = processBuilder.start();

        try {
            process.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
