package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ManageServerActionServlet")
public class ManageServerActionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String version = request.getParameter("version");
        String location = request.getParameter("location");
        int port = Integer.parseInt(request.getParameter("port"));

        String command = "";
        if ("start".equals(action)) {
            command = "/home/sujitha-si2710/" + location + "/postgresql-" + version + "/bin/pg_ctl -D /home/sujitha-si2710/" + location + "/postgresql-" + version + "/data start";
        } else if ("stop".equals(action)) {
            command = "/home/sujitha-si2710/" + location + "/postgresql-" + version + "/bin/pg_ctl -D /home/sujitha-si2710/" + location + "/postgresql-" + version + "/data stop";
        }

        ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", command);
        processBuilder.inheritIO();
        try {
            Process process = processBuilder.start();
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }  

        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
            String sql = "UPDATE installed_versions SET status = ? WHERE port = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, action);
            statement.setInt(2, port);
            statement.executeUpdate();
            String activity = "Server " + action + " : " + port;
            sql = "INSERT INTO activity (activity) VALUES (?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1, activity);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Server Operation Done</h1>");
        out.println("</body></html>");
    }
}
